#pragma once
#include <string>
#include <vector>
#include <map>
#include <iostream>
#include <stdio.h>
#include <windows.h>

#include "sqlite3.h"


const int c_maxInsertStatmentPointers = 200;
const int c_maxSelectStatmentPointers = 200;

enum e_GetRowFromScanMatrixTbl_modes { GetRowBySensorID_e, GetRowByDeviceID_e };

struct SQLiteIf_Params
{
	int holdFramesTimeSpanInSeconds;
	int initMode;				// 0:keep / 1:delete
	bool syncAccess;

	SQLiteIf_Params(const SQLiteIf_Params& from)
	{
		holdFramesTimeSpanInSeconds = from.holdFramesTimeSpanInSeconds;
		initMode = from.initMode;
		syncAccess = from.syncAccess;
	}
	SQLiteIf_Params()
	{
		holdFramesTimeSpanInSeconds = 0;
		initMode = 0;
		syncAccess = false;
	}
};
struct DeviceMapEntry 
{
	std::string sensorID;
	std::string deviceID;
	std::string deviceDispName;
	std::string location;
	std::string matrixID;
	std::string	comment;
	DeviceMapEntry()
	{
		sensorID = "";
		deviceID = "";
		deviceDispName= "";
		location = "";
		matrixID = "";
		comment = "";
	}
};
struct FrameEntry
{
	int ID;
	std::string rcvTimeStamp;
	std::string rcvTimeSpan;
	
	unsigned __int64 depthFrameNum;
	double depthFrameTimeStamp;
	int depthFrameWidth;
	int depthFrameHeight;
	std::string depthFrameFormat;
	int depthFrameSize;

	unsigned __int64 colorFrameNum;
	double colorFrameTimeStamp;
	int colorFrameWidth;
	int colorFrameHeight;
	std::string colorFrameFormat;
	int colorFrameSize;

	std::string colorIntrinsicsData;
	std::string depth2ColorExtrinsicsData;

	std::string	comment;
	
	unsigned char* colorBuf;
	unsigned char* depthXBuf;
	unsigned char* depthYBuf;
	unsigned char* depthZBuf;
	unsigned char* depthUBuf;
	unsigned char* depthVBuf;

	FrameEntry()
	{
		ID = -1;
		rcvTimeStamp = "";
		rcvTimeSpan = "";

		depthFrameNum = 0;
		depthFrameTimeStamp = 0.0;
		depthFrameWidth = 0;
		depthFrameHeight = 0;
		depthFrameSize = 0;
		depthFrameFormat = "";

		colorFrameNum = 0;
		colorFrameTimeStamp = 0.0;
		colorFrameWidth = 0;
		colorFrameHeight = 0;
		colorFrameSize = 0;
		colorFrameFormat = "";

		colorIntrinsicsData = "";
		depth2ColorExtrinsicsData = "";

		comment = "";

		colorBuf = NULL;
		depthXBuf = NULL;
		depthYBuf = NULL;
		depthZBuf = NULL;
		depthUBuf = NULL;
		depthVBuf = NULL;
	}
};
struct PlatformConfig
{
	std::string platformID;
	std::string platformType;
	std::string exeMode;
	int sensorNo;
	int sensorMask;
	int holdFramesInDBMaxCounter;
	std::string extendedInfo;

	PlatformConfig()
	{
		platformID = "";
		platformType = "";
		exeMode = "";
		sensorNo = 0;
		sensorMask = 0;
		holdFramesInDBMaxCounter = 0;
		extendedInfo = "";
	}
};
struct SensorConfig
{
	std::string sensorID;
	int maskIndex;
	std::string location;
	std::string tForm;

	std::string deviceID;
	std::string type;
	std::string opMode;
	std::string configFileName;
	std::string extInfo;

	SensorConfig()
	{
		sensorID = "";
		maskIndex = 0;
		location = "";
		maskIndex = 0;
		deviceID = "";
		type = "";
		opMode = "";
		configFileName = "";
		extInfo = "";
	}
};


class SQLiteIf
{
public:
	SQLiteIf();
	SQLiteIf(std::string runtimeConnStr, std::string persistantConnStr, SQLiteIf_Params& prm);
	~SQLiteIf();

	int init(std::string runtimeConnStr, std::string persistantConnStr, SQLiteIf_Params& prm);
	int terminate();
	int hibernate();
	int wakeup();

	bool isReady();
	bool isErr();
	int getErrCode();
	std::string getVer();
	std::string getLastErrStr();

	// Scan DB interface 
	int createGlobalParamsTable();
	int addRow2GlobalParamsTable(std::string sec, std::string name, std::string value, std::string type, std::string comment);
	
	int createSensorParamsTable(std::string tblName);
	int addRow2SensorParamsTable(std::string sensor, std::string sec, std::string name, std::string value, std::string type, std::string comment);

	int createSensorDeviceMapTable();
	int addRow2SensorDevicesMapTable(std::string sensorId, std::string deviceid, std::string deviceDispName, std::string location, std::string matrixId, std::string comment);
	int getDevicesMapTable(std::map <std::string, DeviceMapEntry>& deviceMap);

	int createFramesTableUnified(std::string devid, int mode);								// 0: default / 1: drop existing table
	int addRow2UnifiedFramesTable(int mode, std::string table, std::string sysTime, std::string unixTimme, FrameEntry& frameEntry);
	int cleanupFrameTable(std::string table, int maxFrames2Hold);

	int getNextFrame(int ID, bool withBlobs, std::string deviceID, FrameEntry& fm);			// ID: [-1- first / 0-last / >0-specific]  
	int getFramesInfo(std::string devid, int& startFrameId, int& framesNo, int& elapsedTimeInSeconds);

	int createScanMatrixParamsTable();
	int addRow2ScanMatrixParamsTable(std::string sensorID, std::string matrixID, std::string location, int valuesNo, std::string values, std::string extendedInfo);
	int getRowFromScanMatrixParamsTable(e_GetRowFromScanMatrixTbl_modes searchMode, std::string searchID, std::string& sensorID, std::string& deviceID, std::string& location, int& numOfValues, std::string& valueString, std::string& extendedInfo);


	
	// Persistant DB interfaces 
	int getCoreConfig(std::string destdb, std::string platform, PlatformConfig& pc, SensorConfig scArray[]);

	int createMatrixTable(int mode);			// 0: default / 1: drop existing table
	int addDefaultMatrixRow2MatrixTable(std::string matrixID, std::string name, std::string type, std::string updateTime, std::string extendedInfo, std::string comment);
	int addRow2MatrixTable(std::string matrixID, std::string name, std::string type, std::string updateTime, std::vector<double> values, std::string extendedInfo, std::string comment);
	int addRow2MatrixTable(std::string matrixID, std::string name, std::string type, std::string updateTime, int numOfValues, std::string valueStr, std::string extendedInfo, std::string comment);
	int getRowFromMatrixTable(std::string matrixID, std::string& name, std::string& type, std::string& updateTime, int& numOfValues, std::string& valueStr, std::string& extendedInfo, std::string& comment);



	// Debug utils
	int createTestFrameTable();					


private:
	const std::string c_version = "[SQLiteIf] - Ver: 7.0";
	const std::string c_accessSyncName = "SQLiteIf_DataIfSyncAccess";
	const int c_busyTiemout = 30000;

	std::string dbConnStr = "";						// runtime DB connection string 
	sqlite3* hdb = NULL;							// runtime handle to the SQLite DB

	std::string pdbName = "";						// persistant DB name
	std::string pdbConnStr = "";					// persistant DB SQLite connection string 
	sqlite3* phdb = NULL;							// persistant handle to the SQLite DB


	sqlite3_stmt* pInsertStatement;					// OBSOLETE
	sqlite3_stmt* pInsertStatementsBank[c_maxInsertStatmentPointers];	// an array so as to make it thread sage (avoid instert statement overide)
	int insertStatmentIndex = 0;

	sqlite3_stmt* pSelectStatementsBank[c_maxSelectStatmentPointers];	// an array so as to make it thread sage (avoid instert statement overide)
	int selectStatmentIndex = 0;

	int state;										// 0: Idle / 1: Ready 
	int errCode = 0;								// SQLITE code
	std::string lastErrStr = "";
	
	bool useAccessSync = true;
	HANDLE  hSqliteAccessSync = NULL;
	SQLiteIf_Params params;


	// Internal DB handlers
	int openDB();									// main per session DB (db handle active from init to terminate)
	int closeDB();
	int dropTable(std::string tblName);
	int execCommand(std::string tblName);
	int execScalarIntCommand(std::string cmd, int& val);
	int execScalarStringCommand(std::string cmd, std::string& retVal);

	int openPDB();									// persistant DB (db handle generated per call due to sporadic usage)
	int closePDB();							
	int dropPTable(std::string tblName);
	int execPCommand(std::string tblName);

	// Internal utils
	time_t getElapsedTimeInSeconds(std::string startTime, std::string endTime);
	std::string getFileName(std::string filePath);
	
};


// In line utils
inline int dbSafeStr2Int(std::string str, int& rc)
{
	int retNum = -1;
	rc = 0;
	try {
		// Wrap up code in try-catch block if string is not validated
		retNum = stoi(str);
	}
	catch (std::invalid_argument e) {
		rc = -1;
	}
	return retNum;
}
inline double dbSafeStr2Double(std::string str, int& rc)
{
	double retNum = -1.1;
	rc = 0;
	try {
		// Wrap up code in try-catch block if string is not validated
		retNum = stod(str);
	}
	catch (std::invalid_argument e) {
		rc = -1;
	}
	return retNum;
}
inline unsigned __int64 dbSafeStr2UInt64(std::string str, int& rc)
{
	unsigned __int64 retNum = 0;
	rc = 0;
	try {
		// Wrap up code in try-catch block if string is not validated
		retNum = stoul(str);
	}
	catch (std::invalid_argument e) {
		rc = -1;
	}
	return retNum;
}
inline int countIntValuesInDelimitedString(std::string str, std::string delimiter)
{
	int count = 0;
	size_t pos = 0;
	while ((pos = str.find(delimiter)) != std::string::npos) 
	{
		str.erase(0, pos + delimiter.length());
		count++;
	}
	if (str.length() > 0)
		count++;		// no delimiter at end of string therefore need to add 1 to count 

	return count;
}
inline time_t str2time_t(std::string str)
{
	int YY, MM, DD, hh, mm, ss;
	struct tm startTm = { 0 };

	sscanf_s(str.c_str(), " %d-%d-%d %d:%d:%d", &YY, &MM, &DD, &hh, &mm, &ss);
	startTm.tm_year = YY - 1900;	//Years from 1900
	startTm.tm_mon = MM - 1;		//0-based
	startTm.tm_mday = DD;			//1 based
	startTm.tm_hour = hh;
	startTm.tm_min = mm;
	startTm.tm_sec = ss;

	return mktime(&startTm);
}

// Obsolete functions
/*
int createTransMatrixTable(int mode);			// 0: default / 1: drop existing table
int addDefaultMatrixRow2TransMatrixTable(std::string deviceID, std::string sensorID, std::string location, std::string updateTime, std::string comment);
int addRow2TransMatrixTable(std::string deviceID, std::string sensorID, std::string location, std::string updateTime, std::vector<double> values, std::string comment);
int addRow2TransMatrixTable(std::string deviceID, std::string sensorID, std::string location, std::string updateTime, std::string numOfValues, std::string valueString, std::string comment);
int getRowFromTransMatrixTable(std::string deviceID, std::string& sensorID, std::string& location, std::string& updateTime, std::string& numOfValues, std::string& valueString, std::string& comment);
*/



