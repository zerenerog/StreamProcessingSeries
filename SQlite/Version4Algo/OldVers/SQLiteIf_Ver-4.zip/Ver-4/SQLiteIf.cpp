#include <iostream>
#include <iomanip>
#include <ctime>
#include <sstream>
#include <string> 

#include "SQLiteIf.h"

SQLiteIf::SQLiteIf()
{
	state = 0;
}
SQLiteIf::SQLiteIf(std::string runtimeConnStr, std::string persistantConnStr, SQLiteIf_Params& inp)
{
	init(runtimeConnStr, persistantConnStr, inp);
	state = 0;
}
SQLiteIf::~SQLiteIf()
{
	terminate();
	state = 0;
}
int SQLiteIf::init(std::string runtimeConnStr, std::string persistantConnStr, SQLiteIf_Params& inp)
{
	int rc = 0;

	dbConnStr = runtimeConnStr;			// reproducable DB conn string
	pdbConnStr = persistantConnStr;		// persistant DB conn string 
	params = inp;						// no worries using copy constructor

	if (dbConnStr.length() <1)
		return -1;
	
	rc = openDB();
	if (rc)
		return -1;

	state = 1;
	return 0;
}
int SQLiteIf::terminate()
{
	if (hdb != NULL)
	{
		sqlite3_close(hdb);
		hdb = NULL;
	}
	state = 0;
	return 0;
}

bool SQLiteIf::isReady()
{
	return (hdb != NULL);
}
bool SQLiteIf::isErr()
{
	return (errCode != 0);
}
int SQLiteIf::getErrCode()
{
	return errCode;
}
std::string SQLiteIf::getVer()
{
	return c_version;
}
std::string SQLiteIf::getLastErrStr()
{
	return lastErrStr;
}


int SQLiteIf::createGlobalParamsTable()
{
	if (!isReady())
		return -1;

	std::string cmd;
	if (params.initMode == 1)
	{
		errCode = dropTable("GlobalParams");
		if (errCode != SQLITE_OK)
			return -11;
	}

	cmd ="CREATE TABLE IF NOT EXISTS [GlobalParams] ([Section] nvarchar(128) NOT NULL, [Name] nvarchar(128) NOT NULL, [ValueStr] nvarchar(128) NOT NULL, [ValueType] nvarchar(128) NULL, [Comment] nvarchar(128) NULL)";
	errCode = execCommand(cmd);
	if (errCode != SQLITE_OK)
		return -11;

	return 0;
}
int SQLiteIf::addRow2GlobalParamsTable(std::string sec, std::string name, std::string value, std::string type, std::string comment)
{
	if (!isReady())
		return -1;

	std::string cmd;

	// Allways clean up the row
	cmd = "DELETE From GlobalParams where Section='" + sec + "' AND name ='" + name + "'";
	errCode = execCommand(cmd);
	if (errCode != SQLITE_OK)
		return -12;

	// Reload 
	cmd = "INSERT INTO GlobalParams (Section ,Name, ValueStr, ValueType, Comment) VALUES ('" + sec + "' , '" + name + "' , '" + value + "' , '" + type + "' , '" + comment + "')";
	errCode = execCommand(cmd);
	if (errCode != SQLITE_OK)
		return -12;

	return 0;
}

int SQLiteIf::createSensorParamsTable(std::string tblName)
{
	if (!isReady())
		return -1;

	std::string cmd;

	errCode = dropTable(tblName);
	if (errCode != SQLITE_OK)
		return -13;

	cmd = "CREATE TABLE IF NOT EXISTS [" + tblName + "]  ([Section] nvarchar(128) NOT NULL, [Name] nvarchar(128) NOT NULL, [ValueStr] nvarchar(128) NOT NULL, [ValueType] nvarchar(128) NULL, [Comment] nvarchar(128) NULL)";
	errCode = execCommand(cmd);
	if (errCode != SQLITE_OK)
		return -14;

	return 0;
}
int SQLiteIf::addRow2SensorParamsTable(std::string sensor, std::string sec, std::string name, std::string value, std::string type, std::string comment)
{
	if (!isReady())
		return -1;

	std::string cmd;

	// Allways clean up the row
	cmd = "DELETE From '" + sensor + "' where Section='" + sec + "' AND name ='" + name + "'";
	errCode = execCommand(cmd);
	if (errCode != SQLITE_OK)
		return -14;

	// Reload 
	cmd = "INSERT INTO " + sensor + " (Section ,Name, ValueStr, ValueType, Comment) VALUES ('" + sec + "' , '" + name + "' , '" + value + "' , '" + type + "' , '" + comment + "')";
	errCode = execCommand(cmd);
	if (errCode != SQLITE_OK)
		return -14;

	return 0;
}

int SQLiteIf::createSensorDeviceMapTable()
{
	if (!isReady())
		return -1;

	std::string cmd;

	errCode = dropTable("DeviceMapping");
	if (errCode != SQLITE_OK)
		return -15;

	cmd = "CREATE TABLE IF NOT EXISTS [DeviceMapping] ([SensorID] nvarchar(128) NOT NULL ,[DevID] nvarchar(128) NOT NULL, [DevName] nvarchar(128) NOT NULL , [Location] nvarchar(128) NOT NULL , [Comment] nvarchar(128) NOT NULL)";
	errCode = execCommand(cmd);
	if (errCode != SQLITE_OK)
		return -15;

	return 0;

}
int SQLiteIf::addRow2SensorDevicesMapTable(std::string sensorId, std::string devid, std::string devname, std::string location, std::string comment)
{
	if (!isReady())
		return -1;

	std::string cmd;

	// Allways clean up the row
	cmd = "DELETE From DeviceMapping where SensorID='" + sensorId + "'";
	errCode = execCommand(cmd);
	if (errCode != SQLITE_OK)
		return -16;

	// Reload 
	cmd = "INSERT INTO DeviceMapping (SensorID, DevID, DevName, Location, Comment) VALUES ('" + sensorId + "' , '" + devid + "' , '" + devname + "' , '" + location + "' , '" + comment + "')";
	errCode = execCommand(cmd);
	if (errCode != SQLITE_OK)
		return -16;

	return 0;
}
int SQLiteIf::getDevicesMapTable(std::map <std::string, DeviceMapEntry>& deviceMap)
{
	if (!isReady())
		return -1;

	std::string cmd;
	sqlite3_stmt* stmt;

	errCode = 0;
	cmd = "SELECT * from [DeviceMapping]";

	// compile sql statement to binary
	errCode = sqlite3_prepare_v2(hdb, cmd.c_str(), -1, &stmt, NULL);
	if (errCode != SQLITE_OK)
	{
		sqlite3_finalize(stmt);
		//sqlite3_clear_bindings(stmt);
		//sqlite3_reset(stmt);
		lastErrStr = sqlite3_errmsg(hdb);
		return -17;
	}

	// Collect and load row data
	int ret_code = 0;
	DeviceMapEntry dm;

	while ((ret_code = sqlite3_step(stmt)) == SQLITE_ROW) 
	{
		dm.sensorID = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 0));
		dm.devID = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 1));
		dm.devName= reinterpret_cast<const char*>(sqlite3_column_text(stmt, 2));
		dm.location = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 3));
		dm.comment = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 4));

		deviceMap.insert(std::make_pair(dm.devID, dm));
	}
	if (ret_code != SQLITE_DONE) 
	{
		sqlite3_finalize(stmt);
		//sqlite3_clear_bindings(stmt);
		//sqlite3_reset(stmt);
		lastErrStr = sqlite3_errmsg(hdb);
		return -17;
	}

	// Cleanup
	sqlite3_finalize(stmt);
	//sqlite3_clear_bindings(stmt);
	//sqlite3_reset(stmt);

	return 0;
}

int SQLiteIf::createFramesTableUnified(std::string tblName, int mode)
{
	if (!isReady())
		return -1;

	std::string cmd;

	if (mode == 1)
	{
		errCode = dropTable(tblName);
		if (errCode != SQLITE_OK)
			return -18;
	}

	cmd = "CREATE TABLE IF NOT EXISTS [" + tblName + "]" +
		" ([ID] integer PRIMARY KEY AUTOINCREMENT NOT NULL" +
		", [RcvTimeStamp] nvarchar(128) NOT NULL" +
		", [RcvTimeSpan] nvarchar(128) NOT NULL" +
		", [ColorFrameNum] nvarchar(128) NOT NULL" +
		", [ColorFrameTimeStamp] nvarchar(128) NOT NULL" +
		", [ColorFrameWidth] nvarchar(128)  NOT NULL"
		", [ColorFrameHeight] nvarchar(128)  NOT NULL"
		", [ColorFrameFormat] nvarchar(128)  NOT NULL"
		", [ColorFrameSize] nvarchar(128)  NOT NULL"
		", [DepthFrameNum] nvarchar(128) NOT NULL" +
		", [DepthFrameTimeStamp] nvarchar(128) NOT NULL" +
		", [DepthFrameWidth] nvarchar(128)  NOT NULL"
		", [DepthFrameHeight] nvarchar(128)  NOT NULL"
		", [DepthFrameFormat] nvarchar(128)  NOT NULL"
		", [DepthFrameSize] nvarchar(128)  NOT NULL"
		", [Comment] nvarchar(128) NULL" +
		", [FrameColor] Blob NULL" +
		", [FrameX] Blob NULL" +
		", [FrameY] Blob NULL" +
		", [FrameZ] Blob NULL" +
		", [FrameU] Blob NULL" +
		", [FrameV] Blob NULL)";
	errCode = execCommand(cmd);
	if (errCode != SQLITE_OK)
		return -18;

	return errCode;
}
int SQLiteIf::addRow2UnifiedFramesTable(int mode, std::string table, std::string sysTime, std::string unixTime, FrameEntry& fe)
{
	if (!isReady())
		return -1;

	int rc = 0;
	std::string cmd;

	std::string dfnum = std::to_string(fe.depthFrameNum);
	std::string dfts = std::to_string(fe.depthFrameTimeStamp);
	std::string dfw = std::to_string(fe.depthFrameWidth);
	std::string dfh = std::to_string(fe.depthFrameHeight);
	std::string dff = fe.depthFrameFormat;
	std::string dfsize = std::to_string(fe.depthFrameSize);

	std::string cfnum = std::to_string(fe.colorFrameNum);
	std::string cfts = std::to_string(fe.colorFrameTimeStamp);
	std::string cfw = std::to_string(fe.colorFrameWidth);
	std::string cfh = std::to_string(fe.colorFrameHeight);
	std::string cff = fe.colorFrameFormat;
	std::string cfsize = std::to_string(fe.colorFrameSize);

	cmd = "INSERT INTO " + table + " (";
	cmd += " RcvTimeStamp, RcvTimeSpan,  ";
	cmd += " DepthFrameNum, DepthFrameTimeStamp, DepthFrameWidth, DepthFrameHeight, DepthFrameFormat, DepthFrameSize, ";
	cmd += " ColorFrameNum, ColorFrameTimeStamp, ColorFrameWidth, ColorFrameHeight, ColorFrameFormat, ColorFrameSize, ";
	if (mode == 0)
	{
		cmd += " comment, ";
		cmd += " FrameColor, FrameX, FrameY, FrameZ, FrameU, FrameV )";
		cmd += " VALUES (? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? )";
		//              1   2   3   4   5   6   7   8   9  10  11  12  13  14  15  16  17  18  19  20  21     
	}
	else
	{
		cmd += " comment)";
		cmd += " VALUES (? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? )";
		//              1   2   3   4   5   6   7   8   9  10  11  12  13  14  15  16  17  18  19  20  21     
	}

	//errCode = sqlite3_exec(hdb, "BEGIN TRANSACTION", NULL, NULL, NULL);
	//if (errCode != SQLITE_OK)
	//{
	//	lastErrStr = sqlite3_errmsg(hdb);
	//	return -111;
	//}

	sqlite3_stmt* pInsertStatementLocal = pInsertStatementsBank[(++insertStatmentIndex)% c_maxInsertStatmentPointers];
	errCode = sqlite3_prepare(hdb, cmd.c_str(), -1, &pInsertStatementLocal, 0);
	if (errCode != SQLITE_OK)
	{
		lastErrStr = sqlite3_errmsg(hdb);
		return -112;
	}

	// Bind filename string and character array (SQL blob of binary array data) to statement handle
	sqlite3_bind_text(pInsertStatementLocal, 1, fe.rcvTimeStamp.c_str() , -1, SQLITE_STATIC);
	sqlite3_bind_text(pInsertStatementLocal, 2, fe.rcvTimeSpan.c_str() , -1, SQLITE_STATIC);
	sqlite3_bind_text(pInsertStatementLocal, 3, dfnum.c_str() , -1, SQLITE_STATIC);
	sqlite3_bind_text(pInsertStatementLocal, 4, dfts.c_str() , -1, SQLITE_STATIC);
	sqlite3_bind_text(pInsertStatementLocal, 5, dfw.c_str(), -1, SQLITE_STATIC);
	sqlite3_bind_text(pInsertStatementLocal, 6, dfh.c_str(), -1, SQLITE_STATIC);
	sqlite3_bind_text(pInsertStatementLocal, 7, dff.c_str(), -1, SQLITE_STATIC);
	sqlite3_bind_text(pInsertStatementLocal, 8, dfsize.c_str(), -1, SQLITE_STATIC);
	sqlite3_bind_text(pInsertStatementLocal, 9, cfnum.c_str(), -1, SQLITE_STATIC);
	sqlite3_bind_text(pInsertStatementLocal,10, cfts.c_str(), -1, SQLITE_STATIC);
	sqlite3_bind_text(pInsertStatementLocal,11, cfw.c_str(), -1, SQLITE_STATIC);
	sqlite3_bind_text(pInsertStatementLocal,12, cfh.c_str(), -1, SQLITE_STATIC);
	sqlite3_bind_text(pInsertStatementLocal,13, cff.c_str(), -1, SQLITE_STATIC);
	sqlite3_bind_text(pInsertStatementLocal,14, cfsize.c_str(), -1, SQLITE_STATIC);

	sqlite3_bind_text(pInsertStatementLocal,15, fe.comment.c_str(), -1, SQLITE_STATIC);

	if (mode == 0)
	{
		sqlite3_bind_blob(pInsertStatementLocal, 16, (const unsigned char*)fe.colorBuf, fe.colorFrameSize, SQLITE_STATIC);
		sqlite3_bind_blob(pInsertStatementLocal, 17, (const unsigned char*)fe.depthXBuf, fe.depthFrameSize, SQLITE_STATIC);
		sqlite3_bind_blob(pInsertStatementLocal, 18, (const unsigned char*)fe.depthYBuf, fe.depthFrameSize, SQLITE_STATIC);
		sqlite3_bind_blob(pInsertStatementLocal, 19, (const unsigned char*)fe.depthZBuf, fe.depthFrameSize, SQLITE_STATIC);
		sqlite3_bind_blob(pInsertStatementLocal, 20, (const unsigned char*)fe.depthUBuf, fe.depthFrameSize, SQLITE_STATIC);
		sqlite3_bind_blob(pInsertStatementLocal, 21, (const unsigned char*)fe.depthVBuf, fe.depthFrameSize, SQLITE_STATIC);
	}

	errCode = sqlite3_step(pInsertStatementLocal);
	if ((errCode != SQLITE_OK) && (errCode != SQLITE_DONE))
	{
		lastErrStr = sqlite3_errmsg(hdb);
		sqlite3_finalize(pInsertStatementLocal);
		return -113;
	}

	//errCode = sqlite3_exec(hdb, "END TRANSACTION", NULL, NULL, NULL);
	//if (errCode != SQLITE_OK)
	//{
	//	lastErrStr = sqlite3_errmsg(hdb);
	//	sqlite3_finalize(pInsertStatementLocal);
	//	return -115;
	//}

	errCode = sqlite3_finalize(pInsertStatementLocal);
	if (errCode != SQLITE_OK)
	{
		lastErrStr = sqlite3_errmsg(hdb);
		sqlite3_finalize(pInsertStatementLocal);
		return -114;
	}


	//sqlite3_clear_bindings(pInsertStatementLocal);
	//sqlite3_reset(pInsertStatementLocal);


	//sqlite3_clear_bindings(pInsertStatementLocal);
	//sqlite3_reset(pInsertStatementLocal);
	// 
	// Execute insert statement with blob 
	//rc = sqlite3_finalize(pInsertStatementLocal);
	//if (rc)
	//	return -1;
	//sqlite3_clear_bindings(pInsertStatementLocal);
	//sqlite3_reset(pInsertStatementLocal);

	return 0;
}
int SQLiteIf::getNextFrame(int ID, bool withBlobs, std::string devid, FrameEntry& fe)
{	// 0: default / 1: just params (no blobs)
	if (!isReady())
		return -1;

	std::string cmd;
	std::string tmps;
	int rc = 0;
	errCode = 0;


	if (!withBlobs)
	{	// Just the frane params (without data blobs)
		cmd = "SELECT ID , RcvTimeStamp, RcvTimeSpan, ";
		cmd += " DepthFrameNum, DepthFrameTimeStamp, DepthFrameWidth, DepthFrameHeight, DepthFrameFormat, DepthFrameSize, ";
		cmd += " ColorFrameNum, ColorFrameTimeStamp, ColorFrameWidth, ColorFrameHeight, ColorFrameFormat, ColorFrameSize, ";
		cmd += " comment ";
		cmd += " FROM [" + devid + "_Frames] ";
		if (ID ==0)
			cmd += " ORDER BY ID DESC LIMIT 1";
		else
			cmd += " WHERE ID = '" + std::to_string(ID) + "'";
	}
	else
	{	// Get info including data blobs
		cmd = "SELECT ID , RcvTimeStamp, RcvTimeSpan, ";
		cmd += " DepthFrameNum, DepthFrameTimeStamp, DepthFrameWidth, DepthFrameHeight, DepthFrameFormat, DepthFrameSize, ";
		cmd += " ColorFrameNum, ColorFrameTimeStamp, ColorFrameWidth, ColorFrameHeight, ColorFrameFormat, ColorFrameSize, ";
		cmd += " comment, ";
		cmd += " FrameColor, FrameX, FrameY, FrameZ, FrameU, FrameV ";
		cmd += " FROM [" + devid + "_Frames]";
		if (ID == 0)
			cmd += " ORDER BY ID DESC LIMIT 1";
		else
			cmd += " WHERE ID = '" + std::to_string(ID) + "'";

		// Reset buffers
		if (fe.depthXBuf)
			free(fe.depthXBuf);
		fe.depthXBuf = NULL;
		if (fe.depthYBuf)
			free(fe.depthYBuf);
		fe.depthYBuf = NULL;
		if (fe.depthZBuf)
			free(fe.depthZBuf);
		fe.depthZBuf = NULL;
		if (fe.depthUBuf)
			free(fe.depthUBuf);
		fe.depthUBuf = NULL;
		if (fe.depthVBuf)
			free(fe.depthVBuf);
		fe.depthVBuf = NULL;
		if (fe.colorBuf)
			free(fe.colorBuf);
		fe.colorBuf = NULL;
	}

	// compile sql statement to binary
	sqlite3_stmt* pSelectStatementLocal = pSelectStatementsBank[(++selectStatmentIndex) % c_maxSelectStatmentPointers];

	//if (sqlite3_prepare_v2(hdb, cmd.c_str(), -1, &pSelectStatementLocal, NULL) != SQLITE_OK)
	errCode = sqlite3_prepare_v2(hdb, cmd.c_str(), -1, &pSelectStatementLocal, NULL);
	if (errCode != SQLITE_OK)
	{
		lastErrStr = sqlite3_errmsg(hdb);
		sqlite3_finalize(pSelectStatementLocal);
		//sqlite3_clear_bindings(pSelectStatementLocal);
		//sqlite3_reset(pSelectStatementLocal);
		return -200;
	}

	// Collect the row  data
	int ret_code = 0;

	while ((ret_code = sqlite3_step(pSelectStatementLocal)) == SQLITE_ROW)
	{
		fe.ID = sqlite3_column_int(pSelectStatementLocal, 0);
		fe.rcvTimeStamp = reinterpret_cast<const char*>(sqlite3_column_text(pSelectStatementLocal, 1));
		fe.rcvTimeSpan = reinterpret_cast<const char*>(sqlite3_column_text(pSelectStatementLocal, 2));

		tmps = reinterpret_cast<const char*>(sqlite3_column_text(pSelectStatementLocal, 3));
		fe.depthFrameNum = dbSafeStr2UInt64(tmps, rc);
		tmps = reinterpret_cast<const char*>(sqlite3_column_text(pSelectStatementLocal, 4));
		fe.depthFrameTimeStamp = dbSafeStr2Double(tmps, rc);
		tmps = reinterpret_cast<const char*>(sqlite3_column_text(pSelectStatementLocal, 5));
		fe.depthFrameWidth = dbSafeStr2Int(tmps, rc);
		tmps = reinterpret_cast<const char*>(sqlite3_column_text(pSelectStatementLocal, 6));
		fe.depthFrameHeight = dbSafeStr2Int(tmps, rc);
		fe.depthFrameFormat = reinterpret_cast<const char*>(sqlite3_column_text(pSelectStatementLocal, 7));
		tmps = reinterpret_cast<const char*>(sqlite3_column_text(pSelectStatementLocal, 8));
		fe.depthFrameSize = dbSafeStr2Int(tmps, rc);

		tmps = reinterpret_cast<const char*>(sqlite3_column_text(pSelectStatementLocal, 9));
		fe.colorFrameNum = dbSafeStr2UInt64(tmps, rc);
		tmps = reinterpret_cast<const char*>(sqlite3_column_text(pSelectStatementLocal, 10));
		fe.colorFrameTimeStamp = dbSafeStr2Double(tmps, rc);
		tmps = reinterpret_cast<const char*>(sqlite3_column_text(pSelectStatementLocal, 11));
		fe.colorFrameWidth = dbSafeStr2Int(tmps, rc);
		tmps = reinterpret_cast<const char*>(sqlite3_column_text(pSelectStatementLocal, 12));
		fe.colorFrameHeight = dbSafeStr2Int(tmps, rc);
		fe.colorFrameFormat = reinterpret_cast<const char*>(sqlite3_column_text(pSelectStatementLocal, 13));
		tmps = reinterpret_cast<const char*>(sqlite3_column_text(pSelectStatementLocal, 14));
		fe.colorFrameSize = dbSafeStr2Int(tmps, rc);

		fe.comment = reinterpret_cast<const char*>(sqlite3_column_text(pSelectStatementLocal, 15));

		if (withBlobs)
		{	// Get the blobs
			try
			{
				fe.colorBuf = (unsigned char*)malloc(fe.colorFrameSize);
				if (fe.colorBuf)
				{
					const void* pReadBolbData = sqlite3_column_blob(pSelectStatementLocal, 16);
					memcpy(fe.colorBuf, pReadBolbData, fe.colorFrameSize);
				}
				fe.depthXBuf = (unsigned char*)malloc(fe.depthFrameSize);
				if (fe.depthXBuf)
				{
					const void* pReadBolbData = sqlite3_column_blob(pSelectStatementLocal, 17);
					memcpy(fe.depthXBuf, pReadBolbData, fe.depthFrameSize);
				}
				fe.depthYBuf = (unsigned char*)malloc(fe.depthFrameSize);
				if (fe.depthYBuf)
				{
					const void* pReadBolbData = sqlite3_column_blob(pSelectStatementLocal, 18);
					memcpy(fe.depthYBuf, pReadBolbData, fe.depthFrameSize);
				}
				fe.depthZBuf = (unsigned char*)malloc(fe.depthFrameSize);
				if (fe.depthZBuf)
				{
					const void* pReadBolbData = sqlite3_column_blob(pSelectStatementLocal, 19);
					memcpy(fe.depthZBuf, pReadBolbData, fe.depthFrameSize);
				}
				fe.depthUBuf = (unsigned char*)malloc(fe.depthFrameSize);
				if (fe.depthUBuf)
				{
					const void* pReadBolbData = sqlite3_column_blob(pSelectStatementLocal, 20);
					memcpy(fe.depthUBuf, pReadBolbData, fe.depthFrameSize);
				}
				fe.depthVBuf = (unsigned char*)malloc(fe.depthFrameSize);
				if (fe.depthVBuf)
				{
					const void* pReadBolbData = sqlite3_column_blob(pSelectStatementLocal, 21);
					memcpy(fe.depthVBuf, pReadBolbData, fe.depthFrameSize);
				}
			}
			catch(std::exception e)
			{
				return -999;
			}
		}
	}
	if (ret_code != SQLITE_DONE)
	{
		lastErrStr = sqlite3_errmsg(hdb);
		sqlite3_finalize(pSelectStatementLocal);
		//sqlite3_clear_bindings(pSelectStatementLocal);
		//sqlite3_reset(pSelectStatementLocal);
		return -101;
	}


	sqlite3_finalize(pSelectStatementLocal);
	//sqlite3_clear_bindings(pSelectStatementLocal);
	//sqlite3_reset(pSelectStatementLocal);
	return errCode;
}
int SQLiteIf::cleanupFrameTable(std::string table, int maxFrames2Hold)
{
	int rc = 0;
	std::string cmd;
	std::string sMaxframes = std::to_string(maxFrames2Hold);
	
	//errCode = sqlite3_exec(hdb, "BEGIN TRANSACTION", NULL, NULL, NULL);
	//if (errCode != SQLITE_OK)
	//{
	//	lastErrStr = sqlite3_errmsg(hdb);
	//	return -300;
	//}

	cmd = "DELETE FROM " + table + " WHERE ID < (MAX(0,(SELECT ID FROM " + table + " ORDER BY ID DESC LIMIT 1) - " + sMaxframes + "))";
	errCode = execCommand(cmd);
	if (errCode != SQLITE_OK)
		return -301;
	//
	//rc = sqlite3_exec(hdb, "END TRANSACTION", NULL, NULL, NULL);
	//if (rc)
	//	return -302;


	return 0;
}


// Persistant DB interfaces 
int SQLiteIf::createTransMatrixTable(int mode)
{
	// This table belongs to the persistant DB 
	int rc = 0;
	std::string cmd;

	// Connection open and closed per call
	try
	{
		rc = openPDB();
		if (rc)
			return -20;

		if (mode == 1)
		{
			errCode = dropPTable("DevicesTransformationMatrix");
			if (errCode != SQLITE_OK)
				return -21;
		}

		cmd = "CREATE TABLE IF NOT EXISTS [DevicesTransformationMatrix] (" \
			"  [DeviceID] nvarchar(128) NOT NULL" \
			", [SensoreID] nvarchar(128) NOT NULL" \
			", [Location] nvarchar(128) NOT NULL" \
			", [UpdateTime] nvarchar(128) NOT NULL" \
			", [NumberOfValues] nvarchar(128) NOT NULL" \
			", [ValuesString] nvarchar(512) NOT NULL" \
			", [Comment] nvarchar(128) NULL)";
		errCode = execPCommand(cmd);
		if (errCode != SQLITE_OK)
			return -21;
	}
	catch (std::exception e)
	{
		lastErrStr = e.what();
		rc = -888;
	}
	rc = closePDB();
	return rc;
}
int SQLiteIf::addDefaultMatrixRow2TransMatrixTable(std::string deviceID, std::string sensorID, std::string location, std::string updateTime, std::string comment)
{
	// Loading default 4X4 diagonal matrix
	std::vector<double> values	{ 1.0, 0 ,  0 , 0 ,
								  0 , 1.0 , 0 , 0 ,
								  0 ,  0  ,1.0, 0 ,
								  0 ,  0  , 0 ,1.0  
								};
	return addRow2TransMatrixTable(deviceID, sensorID, location, updateTime, values, comment);
}
int SQLiteIf::addRow2TransMatrixTable(std::string deviceID, std::string sensorID, std::string location, std::string updateTime, std::vector<double> values, std::string comment)
{
	std::string numOfValues;
	std::string valueString="";
	int len = 0;

	// Format vector to values string <val-1;val-2;...val-n>
	for (double x : values)
	{
		valueString += std::to_string(x) + ";";
		len++;
	}
	numOfValues = std::to_string(len);

	return addRow2TransMatrixTable(deviceID, sensorID, location, updateTime, numOfValues, valueString, comment);
}
int SQLiteIf::addRow2TransMatrixTable(std::string deviceID, std::string sensorID, std::string location, std::string updateTime, std::string numOfValues, std::string valueString, std::string comment)
{
	// This table belongs to the persistant DB 
	int rc = 0;
	std::string cmd;

	// Connection open and closed per call
	try
	{
		rc = openPDB();
		if (rc)
			return -30;

		// Allways clean up the row
		cmd = "DELETE From DevicesTransformationMatrix where DeviceID='" + deviceID + "'";
		errCode = execPCommand(cmd);
		if (errCode != SQLITE_OK)
			return -31;

		// Reload 
		cmd = "INSERT INTO DevicesTransformationMatrix (DeviceID, SensoreID, Location, UpdateTime, NumberOfValues, ValuesString, Comment) ";
		cmd += "VALUES ('" + deviceID + "' , '" + sensorID + "' , '" + location + "' , '" + updateTime + "' , '" + numOfValues + "' , '" + valueString + "' , '" + comment + "')";
		errCode = execPCommand(cmd);
		if (errCode != SQLITE_OK)
			return -32;
	}
	catch (std::exception e)
	{
		lastErrStr = e.what();
		rc = -222;
	}
	rc = closePDB();
	return rc;
}
int SQLiteIf::getRowFromTransMatrixTable(std::string deviceID, std::string& sensorID, std::string& location, std::string& updateTime, std::string& numOfValues, std::string& valueString, std::string& comment)
{
	// This table belongs to the persistant DB 
	int rc = 0;
	std::string cmd;
	sqlite3_stmt* stmt;

	// Connection open and closed per call
	try
	{
		rc = openPDB();
		if (rc)
			return -60;

		errCode = 0;
		cmd = "SELECT * from [DevicesTransformationMatrix] WHERE DeviceID = '" + deviceID + "'";

		// compile sql statement to binary
		errCode = sqlite3_prepare_v2(phdb, cmd.c_str(), -1, &stmt, NULL);
		if (errCode != SQLITE_OK)
		{
			sqlite3_finalize(stmt);
			//sqlite3_clear_bindings(stmt);
			//sqlite3_reset(stmt);
			lastErrStr = sqlite3_errmsg(phdb);
			return -61;
		}

		// Collect and load row data
		int ret_code = 0;
		DeviceMapEntry dm;

		while ((ret_code = sqlite3_step(stmt)) == SQLITE_ROW)
		{
			sensorID = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 1));
			location = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 2));
			updateTime = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 3));
			numOfValues = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 4));
			valueString = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 5));
			comment = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 6));
		}
		if (ret_code != SQLITE_DONE)
		{
			sqlite3_finalize(stmt);
			//sqlite3_clear_bindings(stmt);
			//sqlite3_reset(stmt);
			lastErrStr = sqlite3_errmsg(phdb);
			return -17;
		}

		// Cleanup
		sqlite3_finalize(stmt);
		//sqlite3_clear_bindings(stmt);
		//sqlite3_reset(stmt);
	}
	catch (std::exception e)
	{
		lastErrStr = e.what();
		rc = -666;
	}
	rc = closePDB();
	return rc;
}


// used for debug purposes
int SQLiteIf::createTestFrameTable()
{
	if (!isReady())
		return -1;

	std::string cmd;
	cmd += "CREATE TABLE IF NOT EXISTS [FamesTest]([ID] integer PRIMARY KEY AUTOINCREMENT NOT NULL,[RcvTimeStamp] timestamp NOT NULL, [RcvTimeSpan] int NOT NULL,[Comment] nvarchar(128) NULL,[Frame] Blob NULL)";
	errCode = execCommand(cmd);
	if (errCode != SQLITE_OK)
		return -23;

	return 0;
}

// SQLite generic interface
int SQLiteIf::openDB()
{
	errCode = sqlite3_open(dbConnStr.c_str(), &hdb);
	if (errCode != SQLITE_OK)
	{
		lastErrStr = sqlite3_errmsg(hdb);
		return -1;
	}

	errCode = sqlite3_busy_timeout(hdb, c_busyTiemout);
	if (errCode != SQLITE_OK)
	{
		lastErrStr = sqlite3_errmsg(hdb);
		return -1;
	}

	return 0;
}
int SQLiteIf::dropTable(std::string tblName)
{
	std::string cmd;
	cmd = "DROP TABLE IF EXISTS " + tblName;
	errCode = execCommand(cmd);
	if (errCode != SQLITE_OK)
	{
		lastErrStr = sqlite3_errmsg(hdb);
		return -2;
	}

	return 0;
}
int SQLiteIf::execCommand(std::string cmd)
{
	char* errMsg;

	cmd = cmd.c_str();
	errCode = sqlite3_exec(hdb, cmd.c_str(), NULL, 0, &errMsg);
	return errCode;
}

int SQLiteIf::openPDB()
{
	errCode = sqlite3_open(pdbConnStr.c_str(), &phdb);
	if (errCode != SQLITE_OK)
	{
		lastErrStr = sqlite3_errmsg(phdb);
		return -1;
	}

	errCode = sqlite3_busy_timeout(phdb, c_busyTiemout);
	if (errCode != SQLITE_OK)
	{
		lastErrStr = sqlite3_errmsg(phdb);
		return -1;
	}

	return 0;
}
int SQLiteIf::closePDB()
{
	if (phdb != NULL)
	{
		sqlite3_close(phdb);
		phdb = NULL;
	}
	return 0;
}
int SQLiteIf::dropPTable(std::string tblName)
{
	std::string cmd;
	cmd = "DROP TABLE IF EXISTS " + tblName;
	errCode = execPCommand(cmd);
	if (errCode != SQLITE_OK)
	{
		lastErrStr = sqlite3_errmsg(phdb);
		return -2;
	}

	return 0;
}
int SQLiteIf::execPCommand(std::string cmd)
{
	char* errMsg;

	cmd = cmd.c_str();
	errCode = sqlite3_exec(phdb, cmd.c_str(), NULL, 0, &errMsg);
	return errCode;
}

